// server.cjs
const jsonServer = require('json-server');
const auth = require('json-server-auth');
const cors = require('cors');

const app = jsonServer.create();
const router = jsonServer.router('db.json');

// Habilita CORS e JSON
app.use(cors());
app.use(jsonServer.bodyParser);

// Configuração padrão do json-server-auth
// Roteia automaticamente /register e /login
app.db = router.db;
app.use(auth);
app.use(router);

// Inicia o servidor
app.listen(3000, () => {
  console.log('🚀 Fake API rodando em http://localhost:3000');
});