// api-server.js — Express + json-server based API with JWT auth
const express = require('express');
const jsonServer = require('json-server');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cors = require('cors');

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'minha_chave_secreta_local';

// Use json-server router as lowdb-backed DB
const router = jsonServer.router('db.json');

const app = express();
app.use(cors());
app.use(express.json());

// Simple in-memory blacklist for tokens (logout)
const tokenBlacklist = new Set();

function verificarToken(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ erro: 'Token não fornecido' });
  const token = auth.split(' ')[1];
  if (tokenBlacklist.has(token)) return res.status(401).json({ erro: 'Token inválido' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.usuario = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ erro: 'Token inválido' });
  }
}

// Register
app.post('/register', async (req, res) => {
  const { nome, email, password } = req.body;
  if (!nome || !email || !password) return res.status(400).json({ erro: 'nome, email e password são obrigatórios' });
  const users = router.db.get('users');
  const exists = users.find({ email }).value();
  if (exists) return res.status(400).json({ erro: 'Email já cadastrado' });
  try {
    const hash = await bcrypt.hash(password, 10);
    const novo = { id: Date.now(), nome, email, password: hash };
    users.push(novo).write();
    const { password: _, ...safe } = novo;
    return res.status(201).json(safe);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao criar usuário' });
  }
});

// Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ erro: 'email e password são obrigatórios' });
  const user = router.db.get('users').find({ email }).value();
  if (!user) return res.status(401).json({ erro: 'Usuário não encontrado' });
  try {
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ erro: 'Senha inválida' });
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });
    return res.json({ token });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao efetuar login' });
  }
});

// Logout
app.post('/logout', verificarToken, (req, res) => {
  const token = req.headers.authorization.split(' ')[1];
  tokenBlacklist.add(token);
  return res.json({ mensagem: 'Logout realizado com sucesso' });
});

// Protected
app.get('/protected', verificarToken, (req, res) => {
  return res.json({ mensagem: 'acesso permitido' });
});

// expose db and mount json-server routes for other resources
app.use((req, res, next) => { req.db = router.db; next(); });
app.use('/', router);

app.listen(PORT, () => console.log(`🚀 API rodando em http://localhost:${PORT}`));
