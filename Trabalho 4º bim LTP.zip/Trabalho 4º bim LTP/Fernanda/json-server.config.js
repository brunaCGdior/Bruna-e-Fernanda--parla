module.exports = {
  port: 3000,
  watch: true,
  middlewares: [
    require('json-server-auth')
  ]
}