from flask import Flask

from routes.user_routes import user_bp
from routes.post_routes import post_bp 
from routes.atividade_routes import atividade_bp
from routes.personagem_routes import personagem_bp
from utils.db import init_db

app = Flask(__name__)

app.register_blueprint(user_bp)

# Registra o blueprint de posts, agrupando todas as rotas relacionadas a posts
app.register_blueprint(post_bp)
app.register_blueprint(atividade_bp)
app.register_blueprint(personagem_bp)

@app.before_first_request
def setup():
    init_db()

if __name__ == "__main__":
    app.run(debug=True)

