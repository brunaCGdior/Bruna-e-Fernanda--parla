class Personagem:
    def __init__(self, id, usuario_id, sapato, acessorios, roupa, cabelo, corpo):
        self.id = id
        self.usuario_id = usuario_id
        self.sapato = sapato
        self.acessorios = acessorios
        self.roupa = roupa
        self.cabelo = cabelo
        self.corpo = corpo
