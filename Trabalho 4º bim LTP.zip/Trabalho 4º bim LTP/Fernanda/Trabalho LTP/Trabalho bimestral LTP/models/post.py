class Post:
    def __init__(self, id, user_id, title, content):
        self.id = id
        self.user_id = user_id
        self.title = title
        self.content = content
        self.content = content
