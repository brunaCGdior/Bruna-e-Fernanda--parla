from flask import Flask
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from routes.auth_routes import auth_bp
from routes.atividade_routes import atividade_bp
from routes.personagem_routes import personagem_bp
from routes.post_routes import post_bp
from routes.user_routes import user_bp

app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'chave-super-secreta-parla'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = 3600  # 1 hora

bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# Importar blacklist do auth
from routes.auth_routes import blacklist

@jwt.token_in_blocklist_loader
def verifica_token(jwt_header, jwt_payload):
    return jwt_payload['jti'] in blacklist

# Registro dos Blueprints
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(atividade_bp, url_prefix='/atividade')
app.register_blueprint(personagem_bp, url_prefix='/personagem')
app.register_blueprint(post_bp, url_prefix='/post')
app.register_blueprint(user_bp, url_prefix='/user')

# Rota inicial
@app.route('/')
def index():
    return {'msg': 'API Parla com Autenticação JWT ativa!'}

if __name__ == '__main__':
    app.run(debug=True)
